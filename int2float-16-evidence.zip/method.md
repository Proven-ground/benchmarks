---
title: Conditional LUT resynthesis for int2float
type: evidence
status: current
date: 2026-11-18
creator: Kevin Alexander, Proving Ground EDA
---

# Resynthesis method

We started from EPFL’s 17-LUT size entry, mapped its positional ports to the golden AIG’s port names, and kept the logic outside the private cone for `M[1]`. The replacement uses three LUTs where the original used four.

We partitioned the complete input truth table on the existing exponent signal `E[2]`. For `E[2] = 0`, the target fits in one six-input LUT. For `E[2] = 1`, we chose pins for a helper and for the final LUT. At each assignment of the final LUT’s direct inputs, a pair of rows requiring opposite outputs must have different helper values. Two-coloring the resulting graph on helper input addresses gives the helper truth table. The final LUT reads both helpers and `E[2]`, and uses the corresponding branch on each input. The replacement reuses `M[0]` and existing signals.

The [resulting BLIF](int2float_size_2027.blif) contains 16 six-input LUTs at six levels. The [verification procedure](README.md#replay) establishes its behavior over the complete input domain.
