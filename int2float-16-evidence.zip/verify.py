"""Recheck this submission with Python 3.10+ and no third-party packages."""

import argparse
import hashlib
from io import BytesIO
import itertools
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
GOLDEN = "ad280bdb8331591998b8184ff70ad00d31184649c245796965fc6777e3016bab"
CANDIDATE = "a45d48a6daefea924b0e36664345d84ac906e3ece2ea23452349c6dc7dbd3f5e"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_aig(data):
    stream = BytesIO(data)
    kind, *sizes = stream.readline().split()
    largest, n, latches, m, count = map(int, sizes)
    if kind != b"aig" or latches or (n, m) != (11, 7) or largest != n + count:
        raise ValueError("expected the combinational int2float AIGER format")
    outputs = [int(stream.readline()) for _ in range(m)]

    def delta():
        value = 0
        for shift in range(0, 35, 7):
            byte = stream.read(1)[0]
            value |= (byte & 127) << shift
            if byte < 128:
                return value
        raise ValueError("invalid AIGER delta")

    gates = []
    for var in range(n + 1, largest + 1):
        a = 2 * var - delta()
        b = a - delta()
        if not 0 <= b <= a < 2 * var:
            raise ValueError("invalid AIGER dependency")
        gates.append((var, a, b))
    symbols = {}
    for line in stream.read().decode("ascii").splitlines():
        if line == "c":
            break
        if line:
            key, name = line.split(maxsplit=1)
            if key in symbols:
                raise ValueError("duplicate AIGER symbol")
            symbols[key] = name
    return ([symbols[f"i{i}"] for i in range(n)],
            [symbols[f"o{i}"] for i in range(m)], outputs, gates)


def read_blif(text):
    inputs = outputs = None
    nodes = []
    model = ended = False
    for line in text.splitlines():
        tokens = line.split("#", 1)[0].split()
        if not tokens:
            continue
        key, *args = tokens
        if ended:
            raise ValueError("data after .end")
        if key == ".model" and len(args) == 1 and not model:
            model = True
        elif key == ".inputs" and inputs is None:
            inputs = args
        elif key == ".outputs" and outputs is None:
            outputs = args
        elif key == ".names" and 2 <= len(args) <= 7:
            nodes.append((args[:-1], args[-1], []))
        elif key == ".end" and not args:
            ended = True
        elif (nodes and len(args) == 1 and args[0] == "1"
              and len(key) == len(nodes[-1][0]) and set(key) <= {"0", "1", "-"}):
            nodes[-1][2].append(key)
        else:
            raise ValueError(f"unsupported BLIF line {line!r}")
    if not model or not ended or not inputs or not outputs or not nodes:
        raise ValueError("incomplete BLIF")
    return inputs, outputs, nodes


def table_for(pins, cubes):
    return {bits: any(all(c == "-" or int(c) == bit for c, bit in zip(cube, bits))
                      for cube in cubes)
            for bits in itertools.product(range(2), repeat=len(pins))}


def run(candidate, golden, miter, allow_other_candidate):
    a_data = golden.read_bytes()
    b_data = candidate.read_bytes()
    if sha(a_data) != GOLDEN or (not allow_other_candidate and sha(b_data) != CANDIDATE):
        raise ValueError("input hash mismatch")
    names, out_names, out_literals, gates = read_aig(a_data)
    inputs, outputs, nodes = read_blif(b_data.decode("ascii"))
    if inputs != names or outputs != out_names or len(set(inputs)) != 11 or len(set(outputs)) != 7:
        raise ValueError("ordered ports differ")

    ids = {name: idx for idx, name in enumerate(names, 1)}
    depths = dict.fromkeys(names, 0)
    variables = len(names) + len(gates)
    tables = []
    for pins, name, cubes in nodes:
        if name in ids or len(set(pins)) != len(pins) or any(pin not in ids for pin in pins):
            raise ValueError("BLIF requires distinct pins and topologically ordered single drivers")
        table = table_for(pins, cubes)
        support = sum(any(value != table[bits[:i] + (1 - bits[i],) + bits[i + 1:]]
                          for bits, value in table.items()) for i in range(len(pins)))
        if support < 2:
            raise ValueError("submission contains a constant, buffer or inverter")
        variables += 1
        ids[name] = variables
        depths[name] = 1 + max(depths[pin] for pin in pins)
        tables.append((pins, name, table))
    if any(name not in depths for name in outputs) or len(nodes) != 16 or max(depths[name] for name in outputs) != 6:
        raise ValueError("expected 16 LUTs and 6 output levels")

    if miter:
        # Shared inputs, a complete Boolean definition for each gate, and an
        # OR of output inequalities. UNSAT establishes whole-circuit equality.
        zero = variables + 1
        clauses = [(-zero,)]

        def cnf_literal(literal):
            var = literal // 2 or zero
            return -var if literal & 1 else var

        for var, a, b in gates:
            x, y = cnf_literal(a), cnf_literal(b)
            clauses.extend(((-var, x), (-var, y), (var, -x, -y)))
        for pins, name, table in tables:
            for bits, value in table.items():
                guard = [(-ids[pin] if bit else ids[pin]) for pin, bit in zip(pins, bits)]
                clauses.append((*guard, ids[name] if value else -ids[name]))
        differences = []
        for i, (name, literal) in enumerate(zip(outputs, out_literals), zero + 1):
            x, y = ids[name], cnf_literal(literal)
            clauses.extend(((-i, x, y), (-i, -x, -y), (i, -x, y), (i, x, -y)))
            differences.append(i)
        clauses.append(tuple(differences))
        with miter.open("x", encoding="ascii", newline="\n") as handle:
            handle.write(f"p cnf {differences[-1]} {len(clauses)}\n")
            for clause in clauses:
                handle.write(" ".join(map(str, clause)) + " 0\n")

    for row in range(1 << len(names)):
        inputs_at_row = [(row >> i) & 1 for i in range(len(names))]
        aig = [0, *inputs_at_row]

        def bit(literal):
            return aig[literal // 2] ^ (literal & 1)

        for _, a, b in gates:
            aig.append(bit(a) & bit(b))
        blif = dict(zip(names, inputs_at_row))
        for pins, name, table in tables:
            blif[name] = table[tuple(blif[pin] for pin in pins)]
        for name, literal in zip(outputs, out_literals):
            if blif[name] != bit(literal):
                raise ValueError(f"counterexample input {row}, output {name}")
    return {"status": "equivalent", "inputs_checked": 2048, "outputs_checked": len(outputs),
            "luts": len(nodes), "levels": max(depths[name] for name in outputs),
            "max_fanin": max(len(pins) for pins, _, _ in nodes),
            "candidate_sha256": sha(b_data), "golden_sha256": sha(a_data)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, default=ROOT / "int2float_size_2027.blif")
    parser.add_argument("--golden", type=Path, default=ROOT / "inputs/int2float.aig")
    parser.add_argument("--write-miter", type=Path)
    parser.add_argument("--test-candidate", action="store_true",
                        help="allow a different candidate hash for a negative control")
    args = parser.parse_args()
    try:
        print(json.dumps(run(args.candidate, args.golden, args.write_miter, args.test_candidate), indent=2))
    except (ValueError, KeyError, IndexError, OSError) as exc:
        parser.exit(1, f"verification failed: {exc}\n")


if __name__ == "__main__":
    main()
