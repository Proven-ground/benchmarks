---
title: EPFL int2float in 16 LUTs
type: evidence
status: current
date: 2026-11-18
creator: Kevin Alexander, Proving Ground EDA
---

# EPFL int2float in 16 LUTs

This submission is for the LUT-6 count table.

| Implementation | LUTs | Levels |
| --- | ---: | ---: |
| Published EPFL size entry | 17 | 4 |
| Submitted circuit | **16** | 6 |

The candidate matches the official benchmark on all 2,048 inputs and all seven outputs. ABC confirmed equivalence. CakeLPR checked an LRAT refutation of the whole-circuit inequivalence formula. [EPFL published results](https://github.com/lsils/benchmarks/blob/82d8cc6910419298e713a46644ed59fd3df53038/best_results/README.md)

- [Candidate BLIF](int2float_size_2027.blif) is the submission netlist.
- [Method](method.md) describes the local resynthesis.
- [Verification script](verify.py) evaluates the two circuits and can regenerate the miter using Python 3.10 or later and the standard library.
- [Exhaustive result](evidence/exhaustive-replay.json), [ABC result](evidence/abc.log), and [proof result](evidence/cake-lpr.log) are the recorded checks.
- [Miter CNF](evidence/miter.cnf) and [LRAT refutation](evidence/miter.lrat) certify that no input distinguishes the two circuits.
- [Negative-control netlist](evidence/negative-control.blif) flips one LUT truth-table entry. Both circuit checkers rejected it, the modified miter was SAT, and the original LRAT was rejected against the modified miter.
- [Manifest](manifest.json) records provenance, tool identities, commands and file SHA-256 values. [Checksum list](sha256sums.txt) covers the manifest and the payload.

## Replay

From the unpacked directory, run the exhaustive check and recreate the proof's exact input.

```sh
sha256sum -c sha256sums.txt
python3 -B verify.py --write-miter regenerated.cnf
cmp regenerated.cnf evidence/miter.cnf
```

With ABC and CakeLPR installed separately, run the two independent checks. The ABC executable may be named `abc` or `yosys-abc`.

```sh
yosys-abc -q 'read_blif int2float_size_2027.blif; print_stats; cec inputs/int2float.aig int2float_size_2027.blif'
cake_lpr evidence/miter.cnf evidence/miter.lrat
```

ABC reports `nd = 16`, `lev = 6` and `Networks are equivalent`. CakeLPR reports `s VERIFIED UNSAT`. The verifier compares ordered port names and evaluates the binary AIGER and BLIF independently of ABC.

Replay the negative control with the following command. It exits 1 and reports a counterexample at the all-zero input on `M[1]`.

```sh
python3 -B verify.py --candidate evidence/negative-control.blif --test-candidate
```

The [golden](inputs/int2float.aig) and [published baseline](inputs/int2float_size_2026.blif) are from [EPFL commit 82d8cc6](https://github.com/lsils/benchmarks/tree/82d8cc6910419298e713a46644ed59fd3df53038). Their [MIT license](inputs/epfl-license.txt) is included.
